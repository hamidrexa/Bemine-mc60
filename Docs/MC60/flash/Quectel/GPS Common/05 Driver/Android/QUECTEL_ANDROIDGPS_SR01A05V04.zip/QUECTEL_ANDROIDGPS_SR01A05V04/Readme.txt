1. Please refer to the gps_cfg.inf and Modify the module type,NMEA port path and Baudrate, but you must to make sure the file's format is UNIX format and not the DOS format.
2. Please refer to the "Quectel_Android_GPS_Driver_User_Guide_V1.0" to integrate the GPS driver.
3. If have any problem to integrate the gps driver, Please run the "logcat -s gps_ql -v time" to record the GPS log and contact with quectel.
4. For UC20/EC20/EC21/EC25 module��we support the XTRA function��But need be used together with the latest RIL driver.